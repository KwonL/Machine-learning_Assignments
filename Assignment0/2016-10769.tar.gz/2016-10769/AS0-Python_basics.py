#!/usr/bin/env python
# coding: utf-8

# # M2608.001300 기계학습 기초 및 전기정보 응용<br> Assignment 0: Python Basics

# ## Problem 1: Bubblesort
# 
# 아래 bubblesort 함수를 구현해보세요. 
# YOUR CODE COMES HERE 라는 주석이 있는 곳을 채우면 됩니다.

# In[1]:


def bubblesort(arr):
    for i in range(len(arr) - 1, 0, -1) :
        for j in range(i) :
            if arr[j] > arr[j + 1] :
                arr[j], arr[j + 1] = arr[j + 1], arr[i]
    return arr


# In[2]:


import random
array = [random.randint(0, 20) for _ in range(20)]
print(array)

array_sorted = bubblesort(array)
print(array_sorted)

print()
print('Q: Is the array sorted?')
print('A:', sorted(array) == array_sorted)


# ## Problem 2: Classes
# 
# Quicksort, bubblesort, insertionsort 를 아래 class의 instance method로 구현해 보세요. YOUR CODE COMES HERE 라는 주석이 있는 곳을 채우면 됩니다.

# In[13]:


class Sorter:
    def __init__(self, method):
        self.method = method
        
    @staticmethod
    def of(method):
        return Sorter(method)
        
    def sort(self, arr):
        if self.method == 'quicksort':
            return self.quicksort(arr)
        
        elif self.method == 'bubblesort':
            return self.bubblesort(arr)
        
        elif self.method == 'insertionsort':
            return self.insertionsort(arr)
        
        else:
            raise ValueError('Unknown method: %s' % method)

    def quicksort(self, arr):
        less = list()
        gt = list()
        eq = list()
        
        if len(arr) > 1 :
            p = arr[0]
            for e in arr :
                if e < p :
                    less.append(e)
                elif e > p :
                    gt.append(e)
                else :
                    eq.append(e)
                
            return self.quicksort(less) + eq + self.quicksort(gt)
        else :
            return arr
    
    def bubblesort(self, arr):
        for i in range(len(arr) - 1, 0, -1) :
            for j in range(i) :
                if arr[j] > arr[j + 1] :
                    arr[j], arr[j + 1] = arr[j + 1], arr[i]
        return arr
    
    def insertionsort(self, arr):
        for i in range(1, len(arr)): 
            key = arr[i] 
            j = i-1
            while j >= 0 and key < arr[j] : 
                    arr[j + 1] = arr[j] 
                    j -= 1
            arr[j + 1] = key 
        return arr


# In[14]:


array = [random.randint(0, 20) for _ in range(20)]

algorithms = ['quicksort', 'bubblesort', 'insertionsort']
for algorithm in algorithms:
    sorter = Sorter.of(algorithm)
    array_sorted = sorter.sort(array)
    print('%s sorted? %s' % (algorithm, sorted(array) == array_sorted))


# In[ ]:





# In[ ]:




