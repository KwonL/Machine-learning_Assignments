#!/usr/bin/env python
# coding: utf-8

# # M2608.001300 기계학습 기초 및 전기정보 응용<br> Assignment 1: Logistic Regression

# ## Dataset load & Plot

# In[1]:


get_ipython().run_line_magic('matplotlib', 'inline')
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LogisticRegression


# In[2]:


data = np.loadtxt('data.csv', delimiter=',')
X = data[:, :2]
y = data[:, 2]
label_mask = np.equal(y, 1)

plt.scatter(X[:, 0][label_mask], X[:, 1][label_mask], color='red')
plt.scatter(X[:, 0][~label_mask], X[:, 1][~label_mask], color='blue')
plt.show()


# ## Problem 1-1. sklearn model로 Logistic Regression 모델 train 시켜보기
# scikit-learn library의 LogisticRegression 클래스를 이용해 train 시켜 보세요.

# In[3]:


def learn_and_return_weights(X, y):
    from sklearn.linear_model import LogisticRegression
    
    # YOUR CODE COMES HERE
        
    # w: coefficient of the model to input features,
    # b: bias of the model
    lr = LogisticRegression(solver='liblinear')
    lr.fit(X, y)
    
    w = lr.coef_[0]
    b = lr.intercept_[:, None][0][0]
    
    return w, b


# In[4]:


def plot_data_and_weights(X, y, w, b):
    plt.scatter(X[:, 0][label_mask], X[:, 1][label_mask], color='red')
    plt.scatter(X[:, 0][~label_mask], X[:, 1][~label_mask], color='blue')

    x_lin = np.arange(20, 70)
    y_lin = -(0.5 + b + w[0] * x_lin) / w[1]

    plt.plot(x_lin, y_lin, color='black')
    plt.show()

w, b = learn_and_return_weights(X, y)
plot_data_and_weights(X, y, w, b)


# ## Problem 1-2. numpy로 Logistic Regression 짜보기
# scikit-learn library를 사용하지 않고 Logistic Regression을 구현해보세요.

# In[5]:


def learn_and_return_weights_numpy(X, y):
    # YOUR CODE COMES HERE
    
    # w: coefficient of the model to input features,
    # b: bias of the model
        
    N = np.shape(X)[0]
    d = np.shape(X)[1]
    w = np.zeros(shape = (d, 1))
    b = 0
    lr = 0.1
    newy = 2*y - 1
    
    for i in range(10000):
        wgrad = 0
        bgrad = 0
        h = np.matmul(X, w) + b
        for j in range(N):
            wgrad = wgrad + newy[j] * X[j] * exponential(newy[j] * h[j])
            bgrad = bgrad + newy[j] * exponential(newy[j] * h[j])
        wgrad = wgrad / N
        bgrad = bgrad / N
        wgrad = wgrad[:, np.newaxis]
        w = w + lr * wgrad
        b = b + lr * bgrad
    return w, b

def exponential(x):
    shape = np.shape(x)
    ans = np.zeros(shape = shape)
    i = 0
    for num in x:
        if num < 10 and num > -10:
            ans[i] = 1/(1+np.e ** num)
        elif num <= -10:
            ans[i] = 1
        else:
            ans[i] = 0
        i = i+1
    return ans


# In[6]:


w, b = learn_and_return_weights_numpy(X, y)
plot_data_and_weights(X, y, w, b)


# ## Problem 2. sklearn model로 Logistic Regression 모델 train 시켜보기 + regularizer 사용하기
# scikit-learn library의 Logistic Regression 에 대한 API문서 (https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LogisticRegression.html)를 읽어보고, L1-regularization을 사용할 때와 L2-regularization을 사용할 때의 weight의 변화를 살펴보세요.

# In[7]:


def learn_and_return_weights_l1_regularized(X, y):    
    # YOUR CODE COMES HERE
    lr = LogisticRegression(solver='liblinear', penalty='l1')
    lr.fit(X, y)
    
    w = lr.coef_[0]
    b = lr.intercept_[:, None][0][0]

    return w, b

def learn_and_return_weights_l2_regularized(X, y):    
    # YOUR CODE COMES HERE
    lr = LogisticRegression(solver='liblinear', penalty='l2')
    lr.fit(X, y)
    
    w = lr.coef_[0]
    b = lr.intercept_[:, None][0][0]
    
    return w, b


# In[8]:


def get_dataset():
    D = 1000
    N = 80

    X = np.random.random((N, D))
    w = np.zeros(D)
    w[0] = 1
    w[1] = 1
    
    e = np.random.random(N) - 0.5
    
    y_score = np.dot(X, w)
    y_score_median = np.median(y_score)
    print(y_score.max(), y_score.min(), y_score_median)
    
    # y_score += 0.01 * e
    y = y_score >= y_score_median
    y = y.astype(np.int32)
    
    return (X[:N // 2], y[:N // 2]), (X[N // 2:], y[N // 2:])


# In[9]:


(x_train, y_train), (x_test, y_test) = get_dataset()

w_l1, b_l1 = learn_and_return_weights_l1_regularized(x_train, y_train)
w_l2, b_l2 = learn_and_return_weights_l2_regularized(x_train, y_train)

print(w_l1[:5])
print(w_l2[:5])


# ## Problem 3. Logistic Regression으로 multi-class classification 하기
# Logistic Regression은 기본적으로 binary classifier 입니다. 즉, input *X*를 2개의 class로 밖에 분류하지 못합니다. 하지만, 이같은 Logistic Regression 모델을 연달아 사용한다면 data를 여러 class로 분류할 수도 있겠죠?
# 
# 참고: https://en.wikipedia.org/wiki/Multiclass_classification#Transformation_to_binary

# In[10]:


def get_dataset():
    from keras.datasets import mnist
    (x_train, y_train), (x_test, y_test) = mnist.load_data()
    x_train = x_train.reshape((-1, 28 * 28)).astype(np.float32)
    x_test = x_test.reshape((-1, 28 * 28)).astype(np.float32)
    return (x_train, y_train), (x_test, y_test)
(x_train, y_train), (x_test, y_test) = get_dataset()


# In[11]:


# YOUR CODE COMES IN THIS CELL
# mlr = LogisticRegression(solver='lbfgs', multi_class='auto')
# mlr.fit(x_train, y_train)
# 
# def classifier(x): 
#     y = mlr.predict(x.reshape(1, -1))
#     
#     return y[0] # return label from x.
import time
import random

start = time.time()

sampling_list = sorted(random.sample(range(60000), 1500))
sample_test_x = x_train[sampling_list, :].copy()
sample_test_y = y_train[sampling_list].copy()
mlr = list()

for i in range(10) :
    # print("Now, Training %d" % i) 
    lr = LogisticRegression(solver='lbfgs', max_iter=5000)
    tmp_x, tmp_y = sample_test_x.copy(), sample_test_y.copy()
    
    for idx, k in enumerate(np.nditer(tmp_y)) :
        if k == i :
            tmp_y[idx] = 1
        else :
            tmp_y[idx] = 0
            
    lr.fit(tmp_x, tmp_y)
    
    mlr.append(lr)
    
print("training time: %s" % (time.time() - start))

def classifier(x) :
    pos_list = list()
    cur_ = 0
    max_proba = float()
    
    for idx, lr in enumerate(mlr) :
        proba = lr.predict_proba(x.reshape(1, -1))[0][1]
        if proba > max_proba :
            max_proba = proba
            cur_ = idx
 
    return cur_


# In[12]:


preds = np.array([classifier(x) for x in x_test])
accuracy = np.sum(preds == y_test) / y_test.shape[0]
print('Accuracy:', accuracy)


# In[ ]:




